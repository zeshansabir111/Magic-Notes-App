const $ = (element, multiple=false) => {
    if(multiple == false){
        return document.querySelector(element);
    } else{
        return document.querySelectorAll(element);
    }
}



showNotes();
// Add Note
let addNoteBtn = $('.notesAddBtn');
addNoteBtn.addEventListener('click', addNote);
function addNote(){
    let notes = localStorage.getItem('notes');
    if(notes == null){
        var notesObj = [];
    } else{
        var notesObj = JSON.parse(notes);
    }
    let added =new Date();
    let newNote = {
        title:$('.notesAddTitle').value,
        content:$('.notesAddText').value,
        date: added
    };

    notesObj.push(newNote);
    localStorage.setItem('notes', JSON.stringify(notesObj));
    $('.notesAddTitle').value = "";
    $('.notesAddText').value = "";

    if(notesObj.length != 0){
        showNotes();
    } else{
        $('.notesList').innerHTML = "<p>Empty List</p>";
    }
}
// Show Notes
function showNotes(){
    let notes = localStorage.getItem('notes');
    if(notes == null){
        var notesObj = [];
    } else{
        var notesObj = JSON.parse(notes);
    }

    let noteList = "";
    notesObj.forEach(function(note, index){
        console.log(index);
        noteList += `
        <li class="notesItem">
            <details class="notesItemContainer">
                <summary class="notesItemTitle">${note.title}</summary>
                <p class="notesItemText">${note.content}</p>
            </details>
            <span class="notesSavedDate"><b>Saved Date: </b>${note.date}</span>
            <button id="${index}" type="button" class="notesItemDelete btn btn--trash" onclick="deleteNote(this.id)">Delete</button>
        </li>
        `;
        
        $('.notesList').innerHTML = noteList;
    });
    
}
// Delete a Note
function deleteNote(index){
    let notes = localStorage.getItem('notes');
    if(notes == null){
        var notesObj = [];
    } else{
        var notesObj = JSON.parse(notes);
    }

    notesObj.splice(index, 1);
    localStorage.setItem("notes", JSON.stringify(notesObj));

    if(notesObj.length != 0){
        showNotes();
    } else{
        $('.notesList').innerHTML = "<p>Empty List</p>";
    }
}
